window.CC_DATA = (function () {
const STEPS = [
  { t: 'Initial Credit & Balance Sheet Diagnostic', d: 'We review 3 years of financials, existing debt, CIBIL/CMR scores and collateral to find what a credit officer will question before the file goes out.' },
  { t: 'DPR & CMA Structuring as per Bank Credit Policy', d: "We build the DPR and CMA data to the target banks' policy: debt-equity, DSCR, sensitivity and the working capital assessment method each bank uses." },
  { t: 'Multi-Bank Bid & Sanction Letter Comparison', d: 'The file goes to shortlisted PSU, private bank and NBFC credit hubs together. We compare sanction letters on rate, fees, collateral, covenants and prepayment terms.' },
  { t: 'Legal, Technical Valuation & Subsidy Portal Filing', d: 'We coordinate title search, valuation and TEV agencies, and file MoFPI or State subsidy applications on the same numbers as the loan.' },
  { t: 'Sanction Acceptance & Phased Tranche Disbursement', d: 'After you accept, we handle loan documentation, ROC charge filing and tranche releases linked to construction or machinery milestones.' },
];
const WHY = [
  { t: 'Direct access to Zonal & Central Credit Committees', d: 'Large-ticket files are presented at zonal and central credit hubs of PSU and private banks, where the decision is actually made.' },
  { t: 'Zero upfront retainer fee', d: 'No retainer. Our fee is payable only on sanction, agreed in writing before work starts.' },
  { t: 'CA & ex-banker led financial modeling', d: 'DPR and CMA data prepared by chartered accountants and former bank credit officers, so files are not returned for basic gaps.' },
  { t: 'Parallel subsidy and grant execution', d: 'MoFPI and State subsidy claims are filed alongside the loan, not after it, so the means of finance stays consistent.' },
];
const COMPARE = [
  { k: 'Interest rate negotiation', a: 'One branch quote. Accept it or start again elsewhere.', b: 'PSU, private and NBFC term sheets compared side by side before you sign.' },
  { k: 'Collateral structuring', a: 'Default ask of 100%+ collateral cover.', b: 'Primary security, CGTMSE and pari-passu charge used to reduce collateral load.' },
  { k: 'Moratorium terms', a: 'Standard schedule, rarely matched to your ramp-up.', b: 'Moratorium and step-up repayment set to your construction and revenue timeline.' },
  { k: 'Turnaround time', a: 'File moves branch → region → zone; queries come one at a time.', b: 'Pre-appraised file goes to several credit hubs together; queries answered in one round.' },
  { k: 'DPR & CMA preparation', a: 'Promoter prepares; bank flags gaps later.', b: 'Lender-grade DPR with DSCR, IRR and sensitivity built in from day one.' },
  { k: 'Subsidy filing', a: 'Filed separately after sanction, often on different numbers.', b: 'MoFPI / State incentive filed in parallel on the same DPR.' },
];
const SERVICES = [
{ slug: 'hospital-project-finance', code: 'HPF', calc: 'hospital', title: 'Hospital Project Finance', short: 'hospital projects', blogCat: 'Hospital & Healthcare Finance',
  industry: 'Multispecialty hospitals, nursing homes, diagnostic hubs', ticket: '₹10–250 Cr', tenure: '10–12 years', moratorium: '24–36 months', margin: '25–30%',
  tagline: 'Term debt for greenfield and brownfield hospitals, covering land development, civil works, medical equipment and pre-operative expenses in one sanction.',
  card: ['Up to 70:30 debt-equity on project cost', '24–36 month principal moratorium during construction and bed ramp-up', 'Civil works and medical equipment under one sanction'],
  whatIs: [
    "Hospital project finance is a long-tenor term loan that funds the construction and equipping of a hospital, repaid from the cash the hospital earns once it is running. Banks do not lend against the building alone. They lend against projected bed occupancy, average revenue per occupied bed (ARPOB), and the promoter doctors' ability to bring patients from day one.",
    'The project cost is split into land and civil construction, medical equipment, and pre-operative expenses with margin money for working capital. The term loan covers 65–75% of the total. Promoters bring the balance as equity or as unsecured loans subordinated to the bank. Working capital is sanctioned separately, usually as a cash credit limit against insurance and TPA receivables, and released once billing starts.',
    'Repayment is mapped to the occupancy curve. A 150-bed hospital rarely crosses 60% occupancy in year one, so banks give a 24–36 month moratorium on principal, charge only interest during construction, and start with smaller instalments that step up as occupancy reaches 70–80%. The DPR must show average DSCR of 1.40x or more, with no single year below 1.20x.'],
  formula: { label: 'DSCR (Debt Service Coverage Ratio)', expr: 'DSCR = (PAT + Depreciation + Interest on Term Loan) ÷ (Principal Instalments + Interest on Term Loan)', note: 'Banks look for an average of 1.40x+ on hospital projects. Below 1.25x in any year usually triggers a request for higher promoter margin or a longer tenure.' },
  benefits: [
    { t: 'Long moratorium during construction', d: '24–36 months of interest-only servicing while the building comes up and beds fill.' },
    { t: 'Civil works and equipment in one sanction', d: 'MRI, CT, cath lab and modular OTs are funded with the building, so you avoid separate high-rate equipment loans.' },
    { t: 'Step-up repayment', d: 'Instalments start low and rise with occupancy, keeping DSCR above lender covenants in the early years.' },
    { t: 'Lower rate through lender competition', d: 'Running PSU and private banks in parallel can narrow the spread compared with a single branch quote.' },
    { t: 'Interest during construction capitalised', d: 'IDC is included in project cost, so promoters do not fund it from their own pocket during the build phase.' }],
  bench: [
    { k: 'Minimum promoter contribution', v: '25–30% of project cost' }, { k: 'Acceptable DSCR', v: 'Average 1.40x–1.50x; minimum 1.20x in any year' },
    { k: 'Debt-to-equity ratio', v: 'Up to 70:30 (2.33:1)' }, { k: 'Collateral coverage', v: 'Charge on hospital land, building & equipment; 1.25x–1.50x total cover' },
    { k: 'Credit rating', v: 'External rating of BBB- or better expected for larger exposures' }, { k: 'Repayment tenure', v: '10–12 years including moratorium' }, { k: 'Moratorium', v: '24–36 months from first disbursement' }],
  docs: {
    fin: ['3 years audited balance sheets & P&L of promoter entities', 'ITRs of company and promoter directors (3 years)', 'GST returns & 12-month bank statements', 'CMA data with 10-year projections', 'Net worth statements of promoters & guarantors'],
    tech: ['Detailed Project Report with bed-mix & occupancy model', 'Architectural layout & approved building plan', 'Civil cost estimate certified by a chartered engineer', 'Medical equipment quotations (MRI, CT, OT, ICU)', 'Implementation schedule & CA certificate of cost incurred'],
    stat: ['Land title deeds / registered long-term lease', 'Change of Land Use (CLU) & building plan sanction', 'Pollution Control Board CTE / CTO & biomedical waste authorisation', 'Fire NOC & clinical establishment registration', 'NABH accreditation plan (where applicable)'] },
  faqs: [
    { q: 'How much equity must a doctor-promoter bring for a ₹60 Cr hospital?', a: 'At 70:30, about ₹18 Cr. Banks accept part of it as land already owned (at valuation), unsecured loans from promoters subordinated to the bank, and CA-certified cash already spent on the project.' },
    { q: 'Can I get a 3-year moratorium?', a: 'Yes, for greenfield hospitals with 18–24 months of construction, banks give 24–36 months. Interest is serviced during this period, usually funded through IDC built into project cost.' },
    { q: 'What interest rate should I expect?', a: 'Hospital term loans are typically priced between about 8.75% and 11% p.a., linked to the bank\'s EBLR or MCLR, depending on rating, collateral cover and promoter track record.' },
    { q: 'Is NABH accreditation required before sanction?', a: 'No. Banks want a plan to get NABH within 2–3 years of operation, as it affects insurance empanelment and ARPOB. NABH-accredited hospitals get better pricing on expansion loans.' },
    { q: 'Can an existing hospital loan be taken over at a lower rate?', a: 'Yes. With 12+ months of clean repayment, a balance transfer with a top-up for expansion is common. We compare takeover offers across PSU and private banks.' }],
  seo: { kw: 'hospital project finance', title: 'Hospital Project Finance in India: Rates, DSCR & Process', desc: 'Hospital project finance from ₹10 Cr to ₹250 Cr: 70:30 debt-equity, 24–36 month moratorium, DSCR norms, documents and sanction steps.', slug: 'hospital-project-finance-india' },
  h1: 'Hospital Project Finance in India: How Banks Fund ₹10 Cr to ₹250 Cr Hospital Projects',
  answer: 'Hospital project finance is a term loan of ₹10 Cr to ₹250 Cr+ that funds land development, construction and medical equipment for a new or expanding hospital, at up to 70:30 debt-equity, interest of roughly 8.75%–11% p.a., and repayment over 10–12 years including a 24–36 month moratorium.',
  excerpt: 'How banks appraise hospital projects: occupancy models, 70:30 debt-equity, moratorium, DSCR, and the document list that gets a file sanctioned.', audience: 'For Hospital Promoters & CFOs', read: '14 min read' },

{ slug: 'healthcare-pharma-finance', code: 'HCF', calc: 'hospital', title: 'Healthcare & Pharma Finance Desk', short: 'operating healthcare businesses', blogCat: 'Hospital & Healthcare Finance',
  industry: 'Diagnostic chains, pathology labs, specialty clinics, pharma distributors', ticket: '₹10–75 Cr', tenure: '5–7 years', moratorium: '3–6 months', margin: '15–25%',
  tagline: 'Equipment loans, working capital and expansion debt for running healthcare businesses, sanctioned on cash flows rather than heavy property collateral.',
  card: ['Collateral-light finance for MRI, CT, Cath Lab and lab automation', 'Sanction based on cash flows and doctor-promoter profile', 'Working capital against TPA and insurance receivables'],
  whatIs: [
    'This desk handles debt for healthcare businesses that are already running: diagnostic centres adding an MRI, pathology chains opening new collection centres, specialty clinics expanding, and pharma distributors needing larger working capital. The business has a billing history, so banks appraise the loan on actual cash flows.',
    'Equipment is funded as a term loan with the machine itself as primary security. Banks typically fund 75–85% of the invoice value for new equipment from established OEMs with service networks in India. Collateral may be limited to 25–50% of the loan for promoters with strong professional income and clean banking. Working capital is sized on the receivable cycle: a chain with 45-day TPA receivables gets a cash credit limit set on that cycle.',
    'The bank takes the last 2–3 years of audited EBITDA, adds the revenue the new equipment is expected to bring (scan volumes × average billing), and checks that DSCR stays above 1.30x. A short moratorium of 3–6 months covers installation and AERB licensing for radiology equipment.'],
  formula: { label: 'Incremental cash flow test', expr: 'Monthly EMI ≤ (Scans per day × Avg. billing per scan × 26 days × EBITDA margin) ÷ 1.30', note: 'Banks want the new machine to pay for itself at 1.30x cover, without relying on existing revenue.' },
  benefits: [
    { t: 'Lower collateral load', d: 'Equipment acts as primary security; collateral can be 25–50% of the loan instead of 100%+.' },
    { t: 'Faster credit decisions', d: 'Existing financials let banks decide on actual numbers instead of projections.' },
    { t: 'Term loan and working capital together', d: 'Equipment loan and CC limit against receivables sanctioned in one file.' },
    { t: 'Takeover of high-cost equipment loans', d: 'Move OEM or NBFC equipment loans at 13–16% to bank pricing after 12 months of clean repayment.' },
    { t: 'Professional income counted', d: 'Doctor-promoter consultancy income shown in ITRs is added to repayment capacity.' }],
  bench: [
    { k: 'Minimum promoter contribution', v: '15–25% of equipment / project cost' }, { k: 'Acceptable DSCR', v: '1.30x–1.40x on existing + incremental cash flows' },
    { k: 'Debt-to-equity ratio', v: 'TOL/TNW up to 3:1' }, { k: 'Collateral coverage', v: 'Hypothecation of equipment + 25–50% collateral' },
    { k: 'Credit rating', v: 'Promoter CIBIL 725+; entity CMR rank 1–5' }, { k: 'Repayment tenure', v: '5–7 years' }, { k: 'Moratorium', v: '3–6 months' }],
  docs: {
    fin: ['3 years audited balance sheets & P&L', 'ITRs of entity and doctor-promoters', 'GST returns (last 12 months)', '12-month statements of all operating bank accounts', 'Receivables ageing (TPA, insurance, corporate)', 'Existing loan schedule & sanction letters'],
    tech: ['Equipment proforma invoice & technical specifications', 'Projected scan / test volumes with pricing', 'Site readiness & installation plan', 'Project cost break-up certified by a CA'],
    stat: ['AERB licence / type approval for radiology equipment', 'PCPNDT registration (for ultrasound)', 'Clinical establishment registration', 'NABL / NABH accreditation (if held)', 'Biomedical waste authorisation'] },
  faqs: [
    { q: 'Can I buy a ₹20 Cr MRI without mortgaging property?', a: 'Often, partly. Banks fund 75–85% against the machine and may ask for collateral of 25–50% of the loan, depending on existing cash flows and banking. A strong DSCR and clean repayment record reduce the ask.' },
    { q: 'How is working capital sized for a diagnostic chain?', a: 'On the receivable cycle. If monthly billing is ₹2 Cr and TPA payments take 60 days, the gross requirement is about ₹4 Cr; the bank funds 75% after your 25% margin.' },
    { q: 'I already have an NBFC equipment loan at 14%. Can I move it?', a: 'Yes. After 12 months of regular repayment, banks take over such loans. A 3–5% lower rate usually covers the switching cost within the first year.' },
    { q: 'Does the bank count my consultancy income?', a: 'Yes. Professional income shown in ITRs, if routed through the entity or backed by your guarantee, is added to repayment capacity.' },
    { q: 'How long is the installation moratorium?', a: '3–6 months, covering shipping, installation, AERB clearance and trial runs.' }],
  seo: { kw: 'medical equipment loan', title: 'Healthcare & Medical Equipment Finance in India', desc: 'Finance MRI, CT, cath lab and diagnostic expansion with collateral-light term loans and receivable-based working capital. Norms, documents, FAQs.', slug: 'healthcare-medical-equipment-finance' },
  h1: 'Healthcare & Medical Equipment Finance: MRI, CT and Diagnostic Expansion Loans',
  answer: 'Healthcare and medical equipment finance is a 5–7 year term loan, usually ₹10 Cr to ₹75 Cr, that funds MRI, CT, cath lab and lab automation for operating hospitals and diagnostic chains, with 15–25% promoter margin, interest of about 9%–11.5% p.a., and the equipment itself as primary security.',
  excerpt: 'Collateral-light equipment loans and receivable-based working capital for diagnostic chains, clinics and pharma distributors.', audience: 'For Diagnostic Chains & Doctor-Promoters', read: '12 min read' },

{ slug: 'pharma-api-capex', code: 'PAC', calc: 'pharma', title: 'Pharma & API Capex Debt', short: 'pharma and API plants', blogCat: 'Pharma & API Capex',
  industry: 'Formulation units, bulk drug (API) plants, R&D labs', ticket: '₹15–300 Cr', tenure: '7–10 years', moratorium: '12–24 months', margin: '25–30%',
  tagline: 'Project term loans for WHO-GMP, EU-GMP and USFDA-compliant plants, including cleanrooms, utilities, ETP and validation costs.',
  card: ['Term loans for plant, machinery and cleanrooms', 'ETP, HVAC and utility costs inside project cost', 'Mapping to PLI and State capital subsidy schemes'],
  whatIs: [
    "Pharma and API capex debt funds new manufacturing blocks or full plants for formulations and bulk drugs. Banks appraise these projects on three things: the regulatory pathway (WHO-GMP first, then EU-GMP or USFDA), the product basket and its margins, and the promoter's record of running a compliant plant.",
    'The project cost covers land development, factory building, process equipment, cleanrooms, HVAC, water systems, effluent treatment, and qualification and validation. Banks fund 70–75% as a term loan. Working capital is assessed separately on CMA data, because API businesses carry raw material inventory of 90–120 days and export receivables of 60–90 days.',
    'Cash flows are mapped to the regulatory timeline. A WHO-GMP formulation block can start commercial sales within 6–9 months of mechanical completion; a USFDA filing takes longer. Moratorium is set at 12–24 months, and the DPR must show capacity use rising from about 40% in year one to 75–80% by year three, with average DSCR of 1.35x or more.'],
  formula: { label: 'Net Working Capital requirement', expr: 'NWC = (RM days + WIP days + FG days + Receivable days − Creditor days) × Daily cost of sales', note: 'API units with 120+ day cycles need a working capital limit sanctioned with the term loan, or the new plant runs short of cash in year one.' },
  benefits: [
    { t: 'Full plant cost funded', d: 'Cleanrooms, HVAC, purified water and validation costs included, not only machinery.' },
    { t: 'ETP and utility funding', d: 'Zero-liquid-discharge and solvent recovery systems financed inside project cost.' },
    { t: 'Moratorium matched to approvals', d: '12–24 months to cover commissioning, validation and the first regulatory audit.' },
    { t: 'Export finance on top', d: 'PCFC and EPC limits sanctioned alongside the term loan for export-led units.' },
    { t: 'Scheme linkage', d: 'Project report set up to claim PLI or State capital subsidy where eligible, reducing net debt.' }],
  bench: [
    { k: 'Minimum promoter contribution', v: '25–30% of project cost' }, { k: 'Acceptable DSCR', v: 'Average 1.35x–1.50x; no year below 1.20x' },
    { k: 'Debt-to-equity ratio', v: 'Up to 2.5:1 on project; TOL/TNW below 3:1' }, { k: 'Collateral coverage', v: 'First charge on fixed assets + 1.25x security cover' },
    { k: 'Credit rating', v: 'BBB or better for exposure above ₹50 Cr' }, { k: 'Repayment tenure', v: '7–10 years' }, { k: 'Moratorium', v: '12–24 months' }],
  docs: {
    fin: ['3 years audited balance sheets', 'ITRs & GST returns', 'CMA data with inventory & receivable days', 'Export order book / offtake agreements', 'Promoter net worth statements'],
    tech: ['DPR with product-wise capacity & margin', 'Plant layout & process flow diagrams', 'Machinery, HVAC & cleanroom quotations', 'Civil cost estimate from a chartered engineer', 'Validation & commissioning plan'],
    stat: ['Drug manufacturing licence (State FDA / CDSCO)', 'WHO-GMP / EU-GMP / USFDA certification status', 'Pollution Control Board CTE / CTO', 'Environmental clearance (for API projects)', 'Factory licence & fire NOC'] },
  faqs: [
    { q: 'Will banks fund a new API plant for a first-time manufacturer?', a: 'It is harder. Banks prefer promoters with 3–5 years in pharma manufacturing or marketing. A first-time promoter needs higher margin (35%+), a technical partner and offtake agreements.' },
    { q: 'Is environmental clearance required before sanction?', a: 'For API projects, EC is a pre-disbursement condition and most banks want it before sanction. Formulation units need State Pollution Control Board consent.' },
    { q: 'How is ETP cost treated?', a: 'As part of project cost, funded at the same debt-equity ratio. Zero-liquid-discharge systems can add 8–12% to project cost for API units.' },
    { q: 'Can working capital be sanctioned with the term loan?', a: 'Yes, and it should be. We file both together so the bank assesses the full cash cycle.' },
    { q: 'What DSCR do banks want for pharma projects?', a: 'Average 1.35x–1.50x, with no year below 1.20x. At 10% lower prices or capacity, DSCR must still stay above 1.20x.' }],
  seo: { kw: 'pharma plant loan', title: 'Pharma & API Plant Project Finance in India', desc: 'Term loans for WHO-GMP, EU-GMP and USFDA pharma and API plants: debt-equity, DSCR, moratorium, environmental clearance and documents.', slug: 'pharma-api-plant-project-finance' },
  h1: 'Pharma & API Plant Project Finance: Term Loans for GMP-Compliant Capacity',
  answer: 'Pharma and API capex debt is a 7–10 year project term loan, typically ₹15 Cr to ₹300 Cr, for formulation and bulk drug plants, at 70–75% of project cost, interest of about 9%–11% p.a., and a 12–24 month moratorium aligned to commissioning and GMP approval.',
  excerpt: 'How banks appraise WHO-GMP and USFDA plants: project cost heads, working capital cycles, DSCR and environmental approvals.', audience: 'For Pharma Directors & CFOs', read: '13 min read' },

{ slug: 'industrial-heavy-capex', code: 'IHC', calc: 'industrial', title: 'Industrial Heavy Capex', short: 'industrial plants', blogCat: 'Industrial Loans',
  industry: 'Steel, engineering, chemicals, polymers, auto components', ticket: '₹25–500 Cr', tenure: '7–12 years', moratorium: '12–24 months', margin: '25–35%',
  tagline: "Long-tenor project debt for new plants and capacity expansion, with LC and buyer's credit for imported machinery and finance for captive power.",
  card: ['Long-tenor project term loans up to 12 years', "LC & buyer's credit for imported machinery", 'Captive solar and power plant financing'],
  whatIs: [
    'Industrial capex debt funds a new plant or a large capacity addition in steel, engineering, chemicals, polymers or auto components. The loan is repaid from the cash flows of the new capacity, so the first question a bank asks is whether the market will absorb the extra output at the price shown in your DPR.',
    "Banks split the facility into a rupee term loan for land, building and domestic machinery, and a letter of credit or buyer's credit line for imported machinery. Buyer's credit pays the overseas supplier with foreign-currency funding, later repaid from the term loan. Projects above about ₹100 Cr are often funded by two or more banks under a common loan agreement, with pari-passu charge on fixed assets.",
    'Repayment is mapped to capacity use. Banks typically assume 60–65% in year one, 75% in year two and 80–85% from year three. Captive solar or power plants are appraised on savings in grid power cost, which go straight into DSCR. A 10% sensitivity on raw material and selling price is standard.'],
  formula: { label: 'Fixed Asset Coverage Ratio (FACR)', expr: 'FACR = Net fixed assets ÷ Term loans outstanding', note: 'Banks expect FACR of 1.25x–1.33x throughout the loan. Repayment schedules are set so depreciation does not push it below the floor.' },
  benefits: [
    { t: 'Tenor up to 12 years', d: 'Lower annual principal burden on heavy plant investments.' },
    { t: 'Imported machinery at foreign-currency rates', d: "LC and buyer's credit lower the funding cost of imported equipment during implementation." },
    { t: 'Captive power funded', d: 'Rooftop and ground-mount solar, WHRB and captive power plants financed within the same project.' },
    { t: 'Consortium or multiple banking', d: "Large tickets split across banks so no single lender's exposure cap limits your project." },
    { t: 'State incentives mapped', d: 'Capital subsidy, SGST reimbursement and interest subvention under State industrial policy included in the means of finance.' }],
  bench: [
    { k: 'Minimum promoter contribution', v: '25–35% of project cost' }, { k: 'Acceptable DSCR', v: 'Average 1.40x–1.50x' },
    { k: 'Debt-to-equity ratio', v: 'Up to 2:1 on project; TOL/TNW below 3:1' }, { k: 'Collateral coverage', v: 'First pari-passu charge on fixed assets; FACR 1.25x+' },
    { k: 'Credit rating', v: 'BBB or better; external rating expected above ₹50 Cr exposure' }, { k: 'Repayment tenure', v: '7–12 years' }, { k: 'Moratorium', v: '12–24 months' }],
  docs: {
    fin: ['3 years audited financials + provisional current year', 'ITRs & GST returns', 'CMA data with 10-year projections', 'Existing lender sanction letters & ROC charge details', 'Group company financials'],
    tech: ['Techno-economic viability (TEV) study for large projects', 'DPR with capacity utilisation & price sensitivity', 'Plant layout & process flow', 'Domestic & imported machinery quotations', 'Civil cost estimate from a chartered engineer'],
    stat: ['Land title deeds & CLU / industrial plot allotment', 'Pollution Control Board CTE / CTO', 'Environmental clearance (where applicable)', 'Factory licence & fire NOC', 'Power connection sanction / captive power approvals'] },
  faqs: [
    { q: 'When does a bank ask for a TEV study?', a: 'Usually for projects above ₹50–100 Cr or for new promoters. It is done by a bank-empanelled agency; we coordinate the scope so it matches the DPR.' },
    { q: "How does buyer's credit reduce cost?", a: 'The overseas supplier is paid using foreign-currency funding at a lower rate than rupee term loans for the implementation period. Add hedging cost when comparing.' },
    { q: 'Can a solar plant be funded with the factory?', a: 'Yes. Captive solar is appraised on the grid tariff saved; those savings raise the DSCR of the main project.' },
    { q: 'What if the project cost overruns?', a: 'Banks fund overruns up to a limit, often 10%, at the same debt-equity, if the promoter brings proportionate margin. Keep a 5–10% contingency in the DPR.' },
    { q: 'Do I need a consortium for ₹200 Cr?', a: 'Not always. Many banks can take ₹200 Cr alone for a rated borrower. A consortium spreads risk and often improves pricing.' }],
  seo: { kw: 'industrial project finance', title: 'Industrial Project Finance & Capex Loans in India', desc: "Project term loans for steel, engineering and chemical plants: tenor, buyer's credit, FACR, TEV study, documents and sanction process.", slug: 'industrial-project-finance-capex-loans' },
  h1: 'Industrial Project Finance: Capex Term Loans for New Plants and Expansions',
  answer: 'Industrial capex finance is a project term loan of ₹25 Cr to ₹500 Cr for new plants or expansions in steel, engineering and chemicals, at 65–75% of project cost, interest of about 8.75%–11% p.a., and repayment over 7–12 years after a 12–24 month moratorium.',
  excerpt: "Term loans, buyer's credit and captive power finance for heavy manufacturing: how banks test capacity, prices and FACR.", audience: 'For Factory Owners & CFOs', read: '13 min read' },

{ slug: 'mofpi-food-processing', code: 'FPG', calc: 'food', title: 'MoFPI Food Processing Grants', short: 'food processing projects', blogCat: 'MoFPI Subsidies',
  industry: 'Cold chains, agro-processing clusters, Mega Food Parks, food units', ticket: '₹10–150 Cr', tenure: '7–10 years', moratorium: '12–24 months', margin: '20–25%',
  tagline: 'Bank term loans for food processing projects, filed together with MoFPI capital grants of 35%–50% so grant money reduces your debt.',
  card: ['35%–50% capital grant-in-aid, up to ₹5–10 Cr', 'PMKSY and PMFME scheme compliance', 'Term loan and grant filed on the same DPR'],
  whatIs: [
    'Food processing projects in India can combine a bank term loan with a capital grant from the Ministry of Food Processing Industries (MoFPI). Under PMKSY components such as Integrated Cold Chain, Agro-Processing Clusters and Creation/Expansion of Food Processing Capacities, the grant is typically 35% of eligible project cost in general areas and 50% in difficult areas and for SC/ST promoters, subject to scheme caps of ₹5 Cr to ₹10 Cr.',
    "The grant is released in instalments against project progress, after the bank and promoter have put in their share. So the bank appraises the project as if the grant arrives late, and the means of finance shows promoter margin, term loan and grant separately. Most components require a term loan from a bank or FI, and the bank's appraisal or sanction letter is part of the MoFPI application.",
    'Cash flows are mapped to the season. A cold store fills during harvest and earns rent over the following months, so banks set quarterly instalments matched to that cycle. When the grant arrives, many banks adjust it against the term loan, which reduces EMI or tenure.'],
  formula: { label: 'Means of finance with grant', expr: 'Project cost = Promoter equity + Bank term loan + MoFPI grant (35%–50% of eligible cost, capped)', note: 'Eligible cost usually covers plant & machinery and technical civil works. Land and some building costs fall outside the grant base.' },
  benefits: [
    { t: 'Lower net debt', d: 'Grant of up to ₹5–10 Cr is adjusted against the term loan on release.' },
    { t: 'One DPR for bank and ministry', d: 'Avoids mismatched numbers that cause queries from either side.' },
    { t: 'Right scheme component', d: 'Cold chain, APC and unit schemes each have different eligible costs and caps; the wrong pick loses grant money.' },
    { t: 'Bridge funding for grant delay', d: 'Banks can sanction a bridge facility against the grant receivable.' },
    { t: 'State incentives on top', d: 'State food processing policies add interest subvention or SGST reimbursement.' }],
  bench: [
    { k: 'Minimum promoter contribution', v: '20–25% of project cost' }, { k: 'Acceptable DSCR', v: '1.35x–1.50x (tested before grant)' },
    { k: 'Debt-to-equity ratio', v: 'Up to 3:1 before grant' }, { k: 'Collateral coverage', v: 'First charge on project assets + 1.25x security cover' },
    { k: 'Credit rating', v: 'Bank appraisal letter mandatory for MoFPI filing' }, { k: 'Repayment tenure', v: '7–10 years' }, { k: 'Moratorium', v: '12–24 months' }],
  docs: {
    fin: ['3 years audited financials (or promoter financials for a new entity)', 'ITRs & GST returns', 'CMA data with seasonal cash flows', 'Promoter net worth & proof of equity source', 'Bank term loan sanction / appraisal letter'],
    tech: ['DPR in MoFPI scheme format', 'Plant & machinery quotations', 'Civil cost estimate from a chartered engineer', 'Raw material sourcing / backward linkage plan', 'Layout and process flow chart'],
    stat: ['Land title / lease (minimum tenure per scheme) & CLU', 'FSSAI licence', 'Pollution Control Board CTE / CTO', 'Udyam registration', 'Scheme-specific undertakings & affidavits'] },
  faqs: [
    { q: 'How much grant can a ₹40 Cr cold chain project get?', a: 'Under Integrated Cold Chain, 35% of eligible cost in general areas (50% in difficult areas), capped at ₹10 Cr. If eligible cost is ₹30 Cr, 35% is ₹10.5 Cr, so the grant is capped at ₹10 Cr.' },
    { q: 'Do I need a bank loan to get the MoFPI grant?', a: 'For most PMKSY components, yes. A term loan sanction from a bank or FI is part of the application.' },
    { q: 'When is the grant released?', a: 'In instalments linked to project progress and expenditure, after the bank and promoter share is spent. Plan for 12–24 months from approval.' },
    { q: 'Is PMFME relevant for large projects?', a: 'No. PMFME supports micro units with a 35% credit-linked subsidy capped at ₹10 lakh. Projects above ₹10 Cr fall under PMKSY components.' },
    { q: 'Is land cost counted in the grant?', a: "Generally no. Land is part of project cost for the bank but excluded from the grant's eligible cost." }],
  seo: { kw: 'MoFPI subsidy', title: 'MoFPI Subsidy & Food Processing Loan Guide', desc: 'How to combine a bank term loan with MoFPI capital grants of 35%–50% under PMKSY: eligible cost, caps, documents and release timeline.', slug: 'mofpi-subsidy-food-processing-loan' },
  h1: 'MoFPI Subsidy with Bank Term Loan: Food Processing Project Finance Explained',
  answer: 'MoFPI-linked food processing finance combines a bank term loan of ₹10 Cr to ₹150 Cr with a capital grant of 35%–50% of eligible cost (capped at ₹5–10 Cr) under PMKSY, with 20–25% promoter margin, interest of about 9%–11% p.a., and 7–10 year repayment.',
  excerpt: 'PMKSY grant caps, eligible cost, release timeline and how to file the bank loan and MoFPI claim on one set of numbers.', audience: 'For Food Processing Promoters & FPOs', read: '12 min read' },

{ slug: 'consortium-working-capital', code: 'CWC', calc: 'industrial', title: 'Consortium Working Capital', short: 'working capital limits', blogCat: 'Working Capital & Consortium',
  industry: 'Mid-to-large manufacturers, traders, exporters, EPC contractors', ticket: '₹25–500 Cr', tenure: '12 months, renewable', moratorium: 'Not applicable', margin: '25% on current assets',
  tagline: 'Fund and non-fund working capital from multiple banks, set up so drawing power, charges and security are shared cleanly.',
  card: ['Move from multiple banking to consortium', 'Higher drawing power through correct stock & debtor reporting', 'Pari-passu charge structuring and collateral release'],
  whatIs: [
    'Consortium working capital is a set of cash credit, overdraft, export packing credit, bank guarantee and letter of credit limits provided by two or more banks under a common arrangement. One bank acts as lead, assesses the total requirement, and each member bank takes a share.',
    'The total limit is assessed from your CMA data, by the turnover method for smaller limits or the cash budget / MPBF method for larger ones. Each bank\'s share is backed by a pari-passu first charge on current assets (stock and receivables) plus a common pool of collateral. Non-fund limits like BG and LC are sized on your order book and import cycle.',
    'Your usable limit on any day is the drawing power: eligible stock and receivables, less margin, less creditors. Many companies lose 15–25% of their sanctioned limit because stock statements include ineligible items or receivables older than 90 days. Correct reporting raises the usable limit without a new sanction.'],
  formula: { label: 'Drawing Power (DP)', expr: 'DP = Paid stock × (1 − stock margin) + Receivables < 90 days × (1 − debtor margin) − Creditors', note: 'Typical margins: 25% on stock, 25%–40% on receivables. Receivables older than 90 days are excluded by most banks.' },
  benefits: [
    { t: 'Larger limits than one bank will give', d: "Total requirement shared across banks within each lender's exposure limit." },
    { t: 'One assessment, one set of covenants', d: 'One CMA, one stock audit, one lead bank to deal with.' },
    { t: 'Higher usable drawing power', d: 'Correct stock and debtor statements increase DP within the same sanction.' },
    { t: 'Pari-passu charge and collateral release', d: 'Shared security; excess collateral released when the arrangement is restructured.' },
    { t: 'Pricing competition', d: 'New member banks compete on rate for their share of the limit.' }],
  bench: [
    { k: 'Minimum promoter contribution', v: '25% margin on net working capital' }, { k: 'Acceptable DSCR', v: '1.30x+ on term debt; current ratio 1.33x+' },
    { k: 'Debt-to-equity ratio', v: 'TOL/TNW below 3:1–3.5:1' }, { k: 'Collateral coverage', v: '25%–50% of fund-based limits, pari-passu' },
    { k: 'Credit rating', v: 'BBB- or better; external rating for limits above ₹50 Cr' }, { k: 'Repayment tenure', v: '12 months, renewed annually' }, { k: 'Moratorium', v: 'Not applicable' }],
  docs: {
    fin: ['3 years audited balance sheets & provisional current year', 'CMA data with 2 years of projections', 'Monthly stock & book-debt statements', 'Receivables & payables ageing', 'GST returns, ITRs & 12-month bank statements'],
    tech: ['Order book & customer concentration', 'Import / export cycle details', 'Existing sanction letters from all banks', 'Stock audit reports'],
    stat: ['Board resolution for consortium arrangement', 'ROC charge records (CHG forms)', 'Collateral title deeds & valuation reports', 'Inter-se agreement among banks (via lead bank)'] },
  faqs: [
    { q: 'When should I move from multiple banking to consortium?', a: "When you have 3 or more banks and charges are getting tangled, or when one bank's exposure cap stops further enhancement. Consortium gives one assessment and shared security." },
    { q: 'Why is my drawing power lower than my sanction?', a: 'Usually ineligible stock (slow-moving or unpaid), receivables over 90 days, or high creditors. Fixing stock statements often adds 10–20% of usable limit.' },
    { q: 'Can collateral be released when moving to consortium?', a: 'Yes, if total security cover exceeds what the banks require. We negotiate release of excess collateral as part of the restructure.' },
    { q: 'Do all member banks charge the same rate?', a: 'No. Each member bank prices its own share. We use the bidding stage to bring rates closer together.' },
    { q: 'How long does a consortium setup take?', a: 'Plan for 3–5 months: lead bank assessment, member bank approvals, joint documentation and charge filing.' }],
  seo: { kw: 'consortium working capital', title: 'Consortium Working Capital & Drawing Power Guide', desc: 'How consortium CC, OD, BG and LC limits are assessed, how drawing power is calculated, and how to move from multiple banking to consortium.', slug: 'consortium-working-capital-drawing-power' },
  h1: 'Consortium Working Capital: Assessment, Drawing Power and Pari-Passu Charge',
  answer: 'Consortium working capital is a combined set of cash credit, overdraft, EPC/PCFC, BG and LC limits of ₹25 Cr to ₹500 Cr from two or more banks, assessed on CMA data with 25% promoter margin on current assets, priced at about 8.5%–11% p.a., and renewed every 12 months.',
  excerpt: 'MPBF assessment, drawing power maths and the steps to move from multiple banking to a consortium arrangement.', audience: 'For CFOs of Mid & Large Corporates', read: '11 min read' },

{ slug: 'lease-rental-discounting', code: 'LRD', calc: 'lrd', title: 'Lease Rental Discounting (LRD)', short: 'leased commercial property', blogCat: 'Lease Rental Discounting (LRD)',
  industry: 'Commercial offices, IT parks, malls, warehouses, leased hospitals', ticket: '₹10–500 Cr', tenure: 'Up to 12–15 years', moratorium: 'Nil — EMI from rent', margin: 'LTV 55–65%',
  tagline: 'Loans against future rentals from leased commercial property, repaid directly from rent through an escrow account.',
  card: ['Future rentals discounted up to 12–15 years', 'Tripartite escrow with lessee and bank', 'Lowest-rate bucket to refinance high-cost debt'],
  whatIs: [
    'Lease rental discounting (LRD) is a term loan given against the future rent from a leased commercial property. The bank calculates the present value of rentals for the remaining lease tenure, lends 75%–90% of that value, and takes the property as security.',
    'Repayment comes straight from rent. The lessee pays into an escrow account under a tripartite agreement between owner, lessee and bank. The bank takes its EMI first and releases the balance to the owner. Because the cash flow is contractual, LRD is priced lower than most term loans.',
    "Banks look at the lessee's credit quality as closely as the owner's. Listed or multinational tenants with long lock-in periods get the best terms. The loan is also capped by property value, usually 55%–65% of market value, and by the remaining lease tenure plus renewal options."],
  formula: { label: 'LRD loan eligibility', expr: 'Eligible loan = Lower of [PV of net rentals × 75–90%] and [Market value × 55–65%]', note: 'Net rentals = gross rent − property tax − maintenance borne by the owner. EMI is usually capped at 75–85% of net monthly rent.' },
  benefits: [
    { t: 'Lowest-rate bucket', d: 'Contractual rent attracts some of the lowest pricing in commercial lending.' },
    { t: 'Refinance high-cost debt', d: 'Replace construction loans or private debt with LRD once the building is leased.' },
    { t: 'Capital without selling the asset', d: 'Raise funds against rentals while keeping ownership.' },
    { t: 'Long tenure', d: 'Up to 12–15 years, matched to lease tenure and renewals.' },
    { t: 'Escrow discipline', d: 'Automatic EMI deduction from rent protects your credit record.' }],
  bench: [
    { k: 'Minimum promoter contribution', v: 'Loan-to-value capped at 55–65% of market value' }, { k: 'Acceptable DSCR', v: '1.20x–1.30x on net rentals (EMI ≤ 75–85% of rent)' },
    { k: 'Debt-to-equity ratio', v: 'Secondary test; lessee quality and lease terms drive sanction' }, { k: 'Collateral coverage', v: 'Mortgage of leased property + escrow of rentals' },
    { k: 'Credit rating', v: 'Lessee rated A or better gets best pricing' }, { k: 'Repayment tenure', v: 'Up to 12–15 years (≤ residual lease + renewal)' }, { k: 'Moratorium', v: 'Not applicable; EMI starts with first rent' }],
  docs: {
    fin: ['3 years audited financials of the property-owning entity', 'ITRs & GST returns showing rental income', 'Bank statements with rental credits (12 months)', 'Statements of existing loans on the property'],
    tech: ['Registered lease deeds / leave & licence agreements', 'Rent roll with lock-in, escalation & expiry dates', 'Valuation report from a bank-empanelled valuer', 'Lessee financials or credit profile'],
    stat: ['Property title deeds & 30-year chain of title', 'Occupancy certificate & building approvals', 'Property tax receipts & society / association NOC', 'Tripartite escrow agreement'] },
  faqs: [
    { q: 'How much can I get against ₹50 lakh monthly rent?', a: 'With 9 years of lease left and a 9% rate, the present value of net rentals is roughly ₹33–37 Cr. At 80%, the loan is about ₹26–30 Cr, subject to the property value cap.' },
    { q: 'What if a tenant leaves mid-tenure?', a: 'The loan continues; you find a new tenant or service EMI from other income. Banks may ask for a debt service reserve of 3–6 months of EMI.' },
    { q: 'Can I get LRD on a hospital building leased to an operator?', a: "Yes. Hospital leases with established operators are accepted by several banks, priced on the operator's credit profile." },
    { q: 'Can under-construction property get LRD?', a: 'No. LRD needs an executed lease with rent flowing. Under-construction projects use construction finance, which can be refinanced into LRD later.' },
    { q: 'Does the lock-in period matter?', a: 'Yes. Banks give more weight to rent within the lock-in. A long lock-in with a strong tenant gets a higher loan amount.' }],
  seo: { kw: 'lease rental discounting', title: 'Lease Rental Discounting (LRD) Loan in India', desc: 'LRD loans against commercial rentals: eligibility formula, LTV, escrow structure, tenant quality, documents and how to get the lowest rate.', slug: 'lease-rental-discounting-loan' },
  h1: 'Lease Rental Discounting (LRD): Loans Against Commercial Rental Income',
  answer: 'Lease rental discounting (LRD) is a term loan of ₹10 Cr to ₹500 Cr against future rent from leased commercial property, sized at 75–90% of the present value of rentals and 55–65% of property value, priced at about 8.5%–10.5% p.a., and repaid over up to 12–15 years through an escrow account.',
  excerpt: 'How banks discount future rent: PV maths, LTV caps, tenant quality, escrow structure and the documents a valuer will ask for.', audience: 'For Commercial Property Owners', read: '11 min read' },
];
const PILLAR = {
  slug: 'project-finance-india-guide', blogCat: 'Project Finance', title: 'Project Finance Pillar Guide',
  h1: 'How to Structure ₹10 Cr to ₹100 Cr+ Project Finance in India',
  seo: { kw: 'project finance in India', title: 'How to Structure Project Finance in India (2026)', desc: 'Means of finance, DSCR, debt-equity, PSU vs private bank vs NBFC, and the steps from DPR to disbursement for ₹10 Cr to ₹100 Cr+ projects.', slug: 'project-finance-india-guide' },
  answer: 'Project finance in India for ₹10 Cr to ₹100 Cr+ projects is a term loan covering 60–75% of project cost, repaid over 7–12 years from the project\'s own cash flows, with 25–35% promoter margin, a 12–36 month moratorium, and average DSCR of 1.35x–1.50x.',
  excerpt: 'Means of finance, the ratios credit officers check, choosing between PSU, private and NBFC lenders, and the five mistakes that get files returned.',
  audience: 'For Promoters, CFOs & CAs', read: '18 min read',
  sections: [
    { id: 'means-of-finance', h2: 'How Banks Build the Means of Finance', blocks: [
      { type: 'p', text: 'Every project file starts with two tables: cost of project and means of finance. The bank will not move until both tables balance and every rupee of promoter contribution has a documented source.' },
      { type: 'table', head: ['Component', 'Typical share', 'Source'], rows: [['Promoter equity', '25–35%', 'Share capital, subordinated unsecured loans, land already owned']], more: [['Bank term loan', '60–70%', 'PSU bank, private bank or NBFC'], ['Capital subsidy / grant', '0–15%', 'MoFPI, PLI, State industrial policy'], ['Working capital margin', '25% of NWC', 'Promoter funds, shown in project cost']] }] },
    { id: 'ratios', h2: 'DSCR, IRR and the Numbers Credit Officers Check', blocks: [
      { type: 'p', text: 'A credit officer reads the DPR backwards: repayment schedule first, then the cash flow that pays it, then the assumptions behind that cash flow. If the assumptions look stretched, nothing else in the file matters.' },
      { type: 'callout', label: 'DSCR', expr: 'DSCR = (PAT + Depreciation + Interest on Term Loan) ÷ (Principal + Interest on Term Loan)', note: 'Average 1.40x+ is comfortable. Any single year below 1.20x needs a fix: more equity, a longer tenure or a step-up schedule.' },
      { type: 'table', head: ['Ratio', 'Comfortable level'], rows: [['Average DSCR', '1.35x–1.50x'], ['Minimum DSCR (any year)', '1.20x'], ['Debt-to-equity', '2:1 to 2.33:1'], ['TOL/TNW', 'Below 3:1'], ['FACR', '1.25x or above'], ['Break-even capacity', 'Below 60%']] }] },
    { id: 'lenders', h2: 'PSU Bank vs Private Bank vs NBFC: Which Lender Fits?', blocks: [
      { type: 'p', text: 'There is no single best lender. The right one depends on your rating, collateral, timeline and how unusual your project is.' },
      { type: 'table', head: ['Factor', 'PSU bank', 'Private bank', 'NBFC'], rows: [['Pricing', 'Lowest for rated borrowers', 'Slightly higher', 'Highest'], ['Decision speed', 'Slower, committee-driven', 'Faster', 'Fastest'], ['Collateral appetite', 'Prefers full cover', 'Flexible with cash flows', 'Flexible, priced in'], ['Large tickets', 'Strong', 'Strong', 'Limited by exposure caps'], ['Unusual projects', 'Conservative', 'Case by case', 'Most open']] }] },
    { id: 'process', h2: 'Step-by-Step: From DPR to Disbursement', blocks: [{ type: 'steps', items: STEPS }] },
    { id: 'mistakes', h2: 'Five Mistakes That Get Project Files Returned', blocks: [{ type: 'list', items: [
      { t: 'Promoter margin without a source', d: 'Banks want to see where the equity comes from: bank statements, share allotment, or valued land.' },
      { t: 'Occupancy or capacity jumps', d: 'Projections that hit 85% in year one are cut by the credit officer, and DSCR collapses.' },
      { t: 'No working capital plan', d: 'A new plant with a term loan and no CC limit runs short of cash within months.' },
      { t: 'Approvals pending', d: 'Missing CLU, Pollution Control Board consent or EC stops disbursement after sanction.' },
      { t: 'Subsidy filed on different numbers', d: 'Grant and loan files that do not match invite queries from both the bank and the ministry.' }] }] }],
  faqs: [
    { q: 'What is the minimum project size you handle?', a: 'We work on mandates of ₹10 Cr and above, up to ₹500 Cr.' },
    { q: 'How long does a project loan sanction take?', a: 'With a complete file, 6–12 weeks from submission to sanction for most mid-size projects. TEV studies and consortium approvals add time.' },
    { q: 'Can land already owned count as promoter contribution?', a: 'Yes, at a valuation accepted by the bank, usually the lower of book value and a bank-empanelled valuer\'s figure.' }],
};
PILLAR.sections[0].blocks[1].rows = PILLAR.sections[0].blocks[1].rows.concat(PILLAR.sections[0].blocks[1].more);
return { SERVICES, PILLAR, STEPS, WHY, COMPARE };
})();
